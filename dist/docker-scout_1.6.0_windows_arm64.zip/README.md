- [Docker Scout](#docker-scout)
- [Usage](#usage)
- [CLI Plugin Installation](#cli-plugin-installation)
- [Building](#building)

# Docker Scout

[Docker Scout](https://www.docker.com/products/docker-scout/) is a collection of software supply chain features that appear throughout Docker user interfaces and the command line interface (CLI). These features provide detailed insights into the composition and security of container images.

This repository contains the source code of the `docker scout` CLI plugin.

## Usage

See the [reference documentation](./docs/reference/scout.md).

[Read more](https://docs.docker.com/scout/) about Docker Scout including Docker Desktop and Docker Hub integrations.

## CLI Plugin Installation

Refer to the public [installation instructions](https://github.com/docker/scout-cli#manual-installation).

## Building

### Requirements

- [Go](https://go.dev)
- [Task](https://taskfile.dev)
- [Docker](https://www.docker.com)

### Binary for the Local Architecture

```console
$ task go:build
```

This will create a binary for the local architecture at `dist/docker-scout`.

### Installation

```console
$ task go:install
```

This will create the binary and install it at `~/.docker/cli-plugins/docker-scout`.

### Cross Platform Build

```console
$ task go:snapshot
```

This will create the different binaries for all supported platforms and make them available in `./dist` folder.

### Docker Image

```console
$ task docker:build 
```

This will build a Docker image for the local architecture and load it.

### Multi Arch Docker Image

```console
$ task docker:build:all
```

This will build a multi arch image for the two platforms `linux/amd64` and `linux/arm64`.

 
